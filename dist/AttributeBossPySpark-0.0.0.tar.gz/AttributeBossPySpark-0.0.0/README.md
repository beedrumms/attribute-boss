# Introduction 
This project is supposed to help standardize attributes quickly and at a very high-level so one can perform other operations. The motivation is that most off-self libraries do to much.

AttributeBoss Forever 

Signing off but inevitably back on,
B 

# Getting Started
1.	Installation process
    - Install basic libraries in requirements - newest versions shouldnt be an issue?

# Build and Test
- run python -m setup.py build? 
- run python -m setup.py install?

- run pytest test_xxxx.py in terminal

# Contribute
- contribute freely 
